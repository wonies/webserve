#ifndef WEBSERV_HPP
# define WEBSERV_HPP

# include "config.hpp"
# include "Server.hpp"
# include "HTTP.hpp"

void	run( const int& argc, char* const argv[] );

#endif