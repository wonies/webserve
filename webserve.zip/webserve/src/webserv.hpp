#ifndef WEBSERV_HPP
# define WEBSERV_HPP

# include "config.hpp"
# include "Server.hpp"
# include "HTTP.hpp"

#endif